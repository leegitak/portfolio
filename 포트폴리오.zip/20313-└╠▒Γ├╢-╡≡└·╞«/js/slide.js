setInterval(function () { 
    $('#slide1>ul').delay(2500); $('#slide1>ul').animate({ marginLeft: "-1200px" })
     $('#slide1>ul').delay(2500); $('#slide1>ul').animate({ marginLeft: "-2400px" })
      $('#slide1>ul').delay(2500); $('#slide1>ul').animate({ marginLeft: "0px" })
});

$('#slide3>ul>li').hide();
$('#slide3>ul>li:first-child').show();

setInterval(function(){
    $('#slide3>ul>li:first-child').fadeOut()
    .next().fadeIn().end(1000)
    .appendTo('#slide3>ul');
},3000);
 

